# _verify · 这些脚本是干什么的（教师用，学生不需要看）

本目录是「学生课堂作业包」的**实测证据**。所有结论都是真跑出来的，报告里贴的是**真实命令与真实输出**，
不是估算。重跑只需要 **Python + 本机 Chrome**，**不需要 node_modules / puppeteer**（已删）。

| 文件 | 作用 | 产出报告 |
|---|---|---|
| `make_student_pages.py` | 由教师机 `demos\01/02/03` 三页生成学生版三页（**只改说明性文字，逻辑零改动**），并做「单文件零外部引用」静态自检 | 控制台输出（PASS/FAIL） |
| `student_edit_check.py` | **核心验收**：正则把 `var SNAP_DIST = 0.30;` 改成 `0.45` → 另存临时文件 → 无头 Chrome（file://）读回 `window.__lab.limits().snapDist` 必须 = 0.45；并证明**只改了这一行**、原件未被改动、临时文件已删除 | `student_edit_check.txt` |
| `pages_file_selfcheck.py` | 三页在 `file://` 下的自测：顶层直开 + 探针读 `__errs` / 页面 API / 运行时资源请求（证明零外部请求） | `pages_file_selfcheck.txt` |
| `skheadless.py` | 零依赖无头 Chrome 小工具（`--dump-dom` + 探针 iframe 取值）。**不是 puppeteer**，只用标准库 `subprocess` | — |
| `build_worksheet_print.py` | 把 `01_作业单_90分钟_机房版.md` 转成 A4 打印版 `01_作业单_打印版.html`（勾选框 ☐ / 表格不拆页 / 每页页眉带姓名学号栏） | 控制台输出 |
| `worksheet_print_preview.pdf` | 打印版的真实排版预览（14 页 A4；只作证据，不打进 zip） | — |

## 重跑方式（PowerShell 5.1 即可）

```powershell
$py = "C:\Users\Legion\AppData\Local\Programs\Python\Python314\python.exe"
$v  = "D:\中华女子学院\2026年虚拟现实技术\02_课次资料包\第08次课_20261028\20261028_WebXR交互与模型\学生课堂作业包\_verify"

& $py -X utf8 "$v\make_student_pages.py"      # 1) 从 demos 重新生成学生版三页
& $py -X utf8 "$v\build_worksheet_print.py"   # 2) 重新生成作业单打印版
& $py -X utf8 "$v\student_edit_check.py"      # 3) 可编辑性实测（必须 RESULT: PASS）
& $py -X utf8 "$v\pages_file_selfcheck.py"    # 4) 三页 file:// 自测（必须 PASS；02 那页约 80s）
```

> ⚠️ 顺序别乱：`make_student_pages.py` 会**覆盖** `pages\01_交互实验室_学生版.html`，
> 所以必须**先生成、后验证**。

## 原理：为什么用「探针页 + iframe」而不是 puppeteer

1. 本机 **没有 node_modules**（已删），不能再用 puppeteer；
2. Chrome 的 `--headless=new --dump-dom` 只 dump **主文档** DOM，没法直接读 `window.__lab`；
3. 所以写一个**探针页**（同是 `file://`）：它用 `<iframe>` 打开目标页，靠
   `--allow-file-access-from-files` 跨 file:// 读 `iframe.contentWindow.__lab.limits()`，
   把结果 `JSON.stringify` 进 `<pre id="out">`，再从 dump 出来的 DOM 里取回；
4. 因为页面有 `renderer.setAnimationLoop()` 一直在画，加 `--virtual-time-budget` 让 Chrome 继续跑
   虚拟时间（否则 dump 在 load 就发生，赶不上“等模型加载完”）。

## 诚实边界（这些**没有**验证）

- 全部只在 **headless Chrome + SwiftShader 软件渲染**下验证；真实机房显卡/浏览器版本渲染快慢不同；
- **真机头显/手柄**未验证：VR 会话进入、扳机/握持、触觉执行器、双手同时抓取；
- 没有注入真实鼠标拖拽/键盘事件（只验证页面 API 与 DOM 状态）；
- 「本地导入 GLB」需要真人点文件对话框，headless 不能代点（功能逻辑由教师机 demos 验证覆盖）。
