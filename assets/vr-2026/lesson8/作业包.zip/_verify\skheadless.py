# -*- coding: utf-8 -*-
"""
skheadless.py —— 零依赖无头 Chrome 工具（只用 Python 标准库 + 本机 Chrome，不需要 node_modules / puppeteer）。

为什么这么写（本机实测约束）：
  · 机房与本机都**没有 node_modules**（已删），所以不能再用 puppeteer；CDP 的 Runtime.evaluate 需要
    WebSocket，手写代价高；
  · Chrome 的 `--headless=new --dump-dom` 只输出**主文档**的 DOM，不能直接取值；
  · 于是用「探针页 + iframe」方案：探针页（file:// 同一个源）里 iframe 打开目标页面，
    加 `--allow-file-access-from-files` 后可以跨 file:// 读 `iframe.contentWindow`，
    把要的值 JSON.stringify 进 `<pre id="out">` 与 `<title>`，再由本模块从 dump 里取回。
  · 页面里有 `renderer.setAnimationLoop()` 一直在画，`--dump-dom` 默认在 load 事件就 dump，
    赶不上“模型加载完/等一会儿再看”的需求 → 用 `--virtual-time-budget=<ms>` 让 Chrome 继续跑虚拟时间，
    探针页里的 setTimeout 轮询能跑到，预算用完才 dump。

对外两个函数：
  dump_dom(url, budget_ms=None)      -> (rc, dom_text, elapsed_ms, cmd_str)
  probe(target_uri, extract_js)      -> dict（探针页返回的 JSON，含 cmd/dom 原文便于写进报告）
"""
import html
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time

CHROME = r"C:\Program Files\Google\Chrome\Application\chrome.exe"

PROBE_TMPL = """<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="UTF-8"><title>PROBE_PENDING</title>
<style>body{font-family:Consolas,monospace;font-size:12px}</style></head>
<body>
<pre id="out">PROBE_PENDING</pre>
<iframe id="f" src="%TARGET%" width="480" height="360" style="border:1px solid #999"></iframe>
<script>
(function(){
  var out = document.getElementById('out');
  var f = document.getElementById('f');
  var DEADLINE = Date.now() + %WAIT_MS%;
  var finished = false;
  function write(obj){
    if (finished) return;
    finished = true;
    var s = 'PROBE_JSON=' + JSON.stringify(obj);
    out.textContent = s;
    document.title = s;
  }
  function attempt(){
    var r = { probe: 'skheadless/1', stage: 'probe' };
    try {
      var w = f.contentWindow;
      var d = w.document;
      r.href = String(w.location.href);
      r.readyState = d.readyState;
      r.docTitle = d.title;
      r.bodyTextLen = (d.body && d.body.textContent || '').length;
      r.errs = (w.__errs || []).slice(0, 8);
      r.hasErrsApi = (typeof w.__errs !== 'undefined');
      try {
        r.resourceEntries = w.performance.getEntriesByType('resource').map(function(e){ return e.name; });
      } catch (e) { r.resourceEntries = []; }
      var ex = (function(w, d, r){ %EXTRACT% })(w, d, r);
      for (var k in ex) { r[k] = ex[k]; }
      r.stage = 'ok';
    } catch (e) {
      r.stage = 'error';
      r.error = String((e && e.message) || e);
    }
    return r;
  }
  function loop(){
    var r = attempt();
    if (r.stage !== 'ok' || !r.__pending || Date.now() > DEADLINE) { write(r); return; }
    setTimeout(loop, 150);
  }
  f.addEventListener('load', loop);
  try { if (f.contentDocument && f.contentDocument.readyState === 'complete') loop(); } catch (e) {}
})();
</script>
</body></html>
"""


def _read_when_free(path, tries=40):
    last = None
    for _ in range(tries):
        try:
            with open(path, "rb") as f:
                return f.read()
        except PermissionError as e:  # Chrome 子进程可能短暂持有句柄
            last = e
            time.sleep(0.25)
    raise last


def _run(url, workdir, budget_ms=None, allow_file=True, timeout=120):
    out_path = os.path.join(workdir, "dump.html")
    err_path = os.path.join(workdir, "chrome.err.txt")
    profile = os.path.join(workdir, "profile")
    args = [CHROME,
            "--headless=new",
            "--disable-gpu",
            "--enable-unsafe-swiftshader",
            "--no-first-run",
            "--no-default-browser-check",
            "--disable-extensions",
            "--disable-background-networking",
            "--disable-component-update",
            "--disable-sync",
            "--disable-breakpad",
            "--user-data-dir=" + profile]
    if allow_file:
        args.append("--allow-file-access-from-files")
    if budget_ms:
        args.append("--virtual-time-budget=%d" % int(budget_ms))
    args += ["--dump-dom", url]

    cmd_str = subprocess.list2cmdline(args)
    t0 = time.time()
    with open(out_path, "wb") as fo, open(err_path, "wb") as fe:
        proc = subprocess.Popen(args, stdout=fo, stderr=fe)
        try:
            rc = proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            subprocess.call(["taskkill", "/F", "/T", "/PID", str(proc.pid)],
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            rc = -9
    elapsed = (time.time() - t0) * 1000.0

    try:
        raw = _read_when_free(out_path)
    except PermissionError:
        raw = b""
    if not raw:
        raw = b""
    return rc, raw.decode("utf-8", "replace"), elapsed, cmd_str


def dump_dom(url, budget_ms=None, timeout=120):
    workdir = tempfile.mkdtemp(prefix="skheadless_")
    try:
        return _run(url, workdir, budget_ms=budget_ms, timeout=timeout)
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


def probe(target_uri, extract_js, wait_ms=2500, budget_ms=4000, timeout=150, keep=None):
    """打开「探针页」，由探针页 iframe 打开 target_uri 并取回 JSON。

    extract_js：字符串形式 JS —— 函数体，参数 (w, d, r)，必须 return 一个对象；
                返回对象里设 __pending:true 表示“还没就绪，继续轮询”。
    """
    workdir = tempfile.mkdtemp(prefix="skprobe_")
    try:
        page = (PROBE_TMPL
                .replace("%TARGET%", html.escape(target_uri, quote=True))
                .replace("%EXTRACT%", extract_js)
                .replace("%WAIT_MS%", str(int(wait_ms))))
        page_path = os.path.join(workdir, "probe.html")
        with open(page_path, "w", encoding="utf-8", newline="\n") as f:
            f.write(page)
        probe_uri = _uri(page_path)
        rc, dom, elapsed, cmd = _run(probe_uri, workdir, budget_ms=budget_ms, timeout=timeout)
        if keep:
            try:
                with open(keep, "w", encoding="utf-8", newline="\n") as f:
                    f.write(dom)
            except OSError:
                pass
        result = {"_rc": rc, "_elapsed_ms": round(elapsed, 1), "_cmd": cmd,
                  "_probe_page": probe_uri, "_target": target_uri,
                  "_dom": dom}
        parsed = parse_probe(dom)
        if parsed is None:
            result["_error"] = "探针结果未从 DOM 中取回（dump 长度 %d）" % len(dom)
        else:
            result.update(parsed)
        return result
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


def _uri(path):
    return "file:///" + os.path.abspath(path).replace("\\", "/").replace(" ", "%20")


def parse_probe(dom):
    m = re.search(r'<pre id="out">(PROBE_JSON=.*?)</pre>', dom, re.S)
    if not m:
        m = re.search(r"<title>(PROBE_JSON=.*?)</title>", dom, re.S)
    if not m:
        return None
    payload = html.unescape(m.group(1))[len("PROBE_JSON="):]
    try:
        return json.loads(payload)
    except ValueError:
        return None


if __name__ == "__main__":
    # 自测：本文件可直接跑，确认链路通
    print("chrome:", CHROME, os.path.isfile(CHROME))
    print("python:", sys.version.replace("\n", " "))
    r = dump_dom("data:text/html,<title>sk</title><body>ok")
    print("dump rc=%s elapsed=%.0fms dom=%r" % (r[0], r[2], r[1][:80]))
