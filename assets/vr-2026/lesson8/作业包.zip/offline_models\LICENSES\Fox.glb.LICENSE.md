# Fox.glb — 许可与署名

| 项 | 值 |
|---|---|
| 文件 | `demos/assets/models/Fox.glb`（162,852 B） |
| SHA-256 | `d97044e701822bac5a62696459b27d7b375aada5de8574ed4362edbba94771f7` |
| 几何 | 576 三角面 / 1,728 顶点 / 1 网格 / 1 材质 / 1 纹理(PNG) / 3 动画 / 26 节点 |
| 来源仓库 | KhronosGroup/glTF-Sample-Models（旧仓库）`2.0/Fox` |
| 下载直链 | https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/Fox/glTF-Binary/Fox.glb |
| 模型页 | https://github.com/KhronosGroup/glTF-Sample-Models/tree/master/2.0/Fox |
| README（本结论出处） | https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/Fox/README.md |
| 新仓库 README（更细的拆分） | https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Assets/main/Models/Fox/README.md |

## 一、许可不是一份，是三份（叠加）

| 层次 | 版权持有人 | 许可 | 可商用 | 需署名 |
|---|---|---|---|---|
| 模型本体（低模狐狸） | PixelMannen | **CC0 1.0 Universal** | ✅ | ❌ 不要求 |
| 绑定与动画（骨骼 + 3 段循环） | tomkranis（@tomkranis） | **CC-BY 4.0** | ✅ | ⚠️ **必须** |
| glTF 转换（COLLADA → glTF） | @AsoboStudio、@scurest | **CC-BY 4.0**（新版仓库 README 明确标注） | ✅ | ⚠️ **必须** |

**整体判定：可商用；必须署名**（取最严格的一层）。

## 二、源站原文片段

旧仓库 `2.0/Fox/README.md` 的 `License Information` 段原文：

```
## License Information

[CC0](https://creativecommons.org/publicdomain/zero/1.0/): Low poly fox [by PixelMannen](https://opengameart.org/content/fox-and-shiba)

[CC-BY 4.0](https://creativecommons.org/licenses/by/4.0/): Rigging and animation [by @tomkranis on Sketchfab](https://sketchfab.com/models/371dea88d7e04a76af5763f2a36866bc)

glTF conversion [by @AsoboStudio and @scurest](https://github.com/KhronosGroup/glTF-Sample-Models/pull/150#issuecomment-406300118)
```

新版仓库 `Models/Fox/README.md` 的 `Legal` 段（把转换也明确成 CC-BY 4.0）：

```
© 2014, Public. Creative Commons Zero v1.0 Universal
 - PixelMannen for Model

© 2014, tomkranis. Creative Commons Attribution 4.0 International
 - tomkranis for Rigging & Animation

© 2017, @AsoboStudio and @scurest. Creative Commons Attribution 4.0 International
 - @AsoboStudio and @scurest for Conversion to glTF
```

## 三、文件内自带的版权声明（GLB `asset.copyright` 字段原文）

解析命令：`python demos\tools\glb_stats.py demos\assets\models\Fox.glb`
输出中的 `asset.copyright`：

```
CC-BY 4.0 Model by PixelMannen https://opengameart.org/content/fox-and-shiba
and @tomkranis https://sketchfab.com/3d-models/low-poly-fox-by-pixelmannen-animated-371dea88d7e04a76af5763f2a36866bc
and @AsoboStudio with @scurest https://github.com/KhronosGroup/glTF-Sample-Models/pull/150#issuecomment-406300118
```

> 教学点：许可信息会**跟着文件走**。这正是「下载后立刻记账」的理由——文件分享几手之后，源站链接早丢了，但 `asset.copyright` 还在。

## 四、可直接粘贴的署名文本

**中文版**（学生作品里放这个）：

```
模型：Fox（低模狐狸）
- 模型本体：PixelMannen，CC0 1.0 — https://opengameart.org/content/fox-and-shiba
- 绑定与动画：@tomkranis，CC-BY 4.0 — https://sketchfab.com/models/371dea88d7e04a76af5763f2a36866bc
- glTF 转换：@AsoboStudio 与 @scurest，CC-BY 4.0
- 获取渠道：Khronos glTF-Sample-Models — https://github.com/KhronosGroup/glTF-Sample-Models/tree/master/2.0/Fox
```

**英文版**（对外发布 / 比赛模板）：

```
Fox by PixelMannen (CC0 1.0), rigging & animation by @tomkranis (CC BY 4.0),
glTF conversion by @AsoboStudio and @scurest (CC BY 4.0).
Source: Khronos glTF-Sample-Models.
```

## 五、许可全文链接

- CC0 1.0：https://creativecommons.org/publicdomain/zero/1.0/legalcode
- CC-BY 4.0：https://creativecommons.org/licenses/by/4.0/legalcode

## 六、课堂可用性

✅ **可用**。用途：`02_模型工作台_WebXR.html` 的内嵌模型（播放 Survey / Walk / Run 三段动画）。
义务：把上面「中文版署名」放进作品展示或项目说明里即可，不需要付费、不需要联系作者。
