# -*- coding: utf-8 -*-
"""
make_student_pages.py —— 由教师机 demos/ 的三页生成「学生课堂作业包 / pages /」三页。

设计纪律（本脚本只做“说明性文字”替换，绝不改任何代码逻辑）：
  · 01：把「开发版模板 + 构建」说明换成「直接改学生练习区 → 保存 → 刷新」；
        并在文件末尾追加一段「学生练习区 · 文件末尾速查」HTML 注释。
  · 02/03：把页面顶部注释、页面可见的 meta 行、以及“改完运行 xxx.py”的提示
        换成学生版说法；脚本/库/模型 base64 一个字节不动。
替换采用「精确整段匹配 + 计数必须为 1」，任何一处对不上就报错退出（防止静默漏改）。

用法（PowerShell 5.1 可用）：
  C:\\Users\\Legion\\AppData\\Local\\Programs\\Python\\Python314\\python.exe make_student_pages.py
"""
import hashlib
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)                       # 学生课堂作业包\
DEMOS = os.path.join(os.path.dirname(PKG), "demos")
PAGES = os.path.join(PKG, "pages")

PAGE01_SRC = os.path.join(DEMOS, "01_交互实验室_WebXR.html")
PAGE02_SRC = os.path.join(DEMOS, "02_模型工作台_WebXR.html")
PAGE03_SRC = os.path.join(DEMOS, "03_模型转换器.html")

PAGE01_DST = os.path.join(PAGES, "01_交互实验室_学生版.html")
PAGE02_DST = os.path.join(PAGES, "02_模型工作台_WebXR.html")
PAGE03_DST = os.path.join(PAGES, "03_模型转换器.html")

# 期望源文件 SHA-256（与 demos/_verify/*_report.txt 的成品一致；不一致只告警，不中断）
EXPECT = {
    PAGE01_SRC: ("675366", "f6d7bd92d5925eb7cefea885a7889f0ea3e35717fa9241c0c565bcfc3ec00bd1"),
    PAGE02_SRC: ("2805064", None),
    PAGE03_SRC: ("941810", None),
}

# 机房学生页里禁止出现的“会让学生卡住”的指令式文案
FORBIDDEN_IN_PAGES = [
    "改完运行",
    "python tools",
    "build_interaction.py",
    "python -m http.server",
    "重新生成单文件页",
]

# 唯一允许保留的构建痕迹：02/03 的 BUILD_INFO 里 "generated_by" 是来源字段（不是给学生执行的指令）。
# 扫描前把它剥离，并在报告里单独说明。
PROVENANCE = '"generated_by": "tools/build_workbench.py",'

report = []


def log(msg=""):
    print(msg)
    report.append(msg)


def sha256(b):
    return hashlib.sha256(b).hexdigest()


def read_text(path):
    with open(path, "rb") as f:
        raw = f.read()
    return raw, raw.decode("utf-8")


def apply(text, old, new, tag, must=1):
    n = text.count(old)
    if n != must:
        log("!! [%s] 期望匹配 %d 处，实际 %d 处 —— 中止（源文件版本可能已变）" % (tag, must, n))
        raise SystemExit(2)
    log("   [%s] 替换 %d 处（%d 字符 → %d 字符）" % (tag, n, len(old), len(new)))
    return text.replace(old, new)


# ============================ 01 交互实验室 ============================
P01 = []

P01.append((
    "01/抬头-两种形态",
    """ * 两种形态（同一份代码）：
 *   · 开发版模板 = 本文件（demos\\src\\01_交互实验室_template.html，库用 ../lib/three.min.js 外链）
 *   · 单文件成品 = demos\\01_交互实验室_WebXR.html（three r128 内联，零外部请求，双击可看）
 *   构建：python tools\\build_interaction.py""",
    """ * 【学生版 · 646 机房可直接改】本文件已是「单文件成品」：three r128 已内联、零外部请求，
 *   双击即可打开；不需要 Python / Node / 服务器 / 网络。
 *   · 要改参数：**直接改本文件末尾「学生练习区」里的数字**（Ctrl+F 搜「学生练习区」即可定位）→
 *     Ctrl+S 保存 → 浏览器 F5 刷新即可，无需构建。""",
))

P01.append((
    "01/学生练习区开头",
    """/* =========================================================================
 * ===== 学生练习区 · 从这里开始改 =====
 * 本文件是「开发版模板」（库用外部引用 ../lib/three.min.js，约 68 KB，好改好定位）。
 * 改完 → 在 demos 目录运行  python tools\\build_interaction.py
 *      → 重新生成单文件成品 demos\\01_交互实验室_WebXR.html（约 670 KB，零外部请求，双击可看）
 *
 * 练习 1-A：改吸附判定半径 —— 找到 SNAP_DIST（默认 0.30 m）""",
    """/* =========================================================================
 * ===== 学生练习区 · 从这里开始改 =====
 * 本文件是「学生版 · 单文件」：three.js 已内联，双击即可运行。
 *
 * 【怎么改 · 三步】
 *   ① 用任意文本编辑器打开本文件（记事本 / VS Code 都行），Ctrl+F 搜「学生练习区」→ 就到这里。
 *   ② 直接改下面的数字（或照抄一行新代码）；改的就是这一个 .html 文件本身。
 *   ③ Ctrl+S 保存 → 回到浏览器按 F5 刷新 → 立刻生效。
 *   不需要构建、不需要 Python、不需要 Node、不需要服务器、不需要联网。
 *   （PC 演示双击即可；要用 VR 才需要 http 地址，做法见作业包「00_先读我」。）
 *
 * 练习 1-A：改吸附判定半径 —— 找到 SNAP_DIST（默认 0.30 m）""",
))

P01.append((
    "01/标题",
    "<title>01 交互实验室 · WebXR 交互进阶</title>",
    "<title>01 交互实验室 · WebXR 交互进阶（学生版·单文件）</title>",
))

P01.append((
    "01/HUD 开发版提示",
    """  $('hudDev').innerHTML = '开发版：<b>src\\\\01_交互实验室_template.html</b>' +
    '（改完运行 <span class="k">python tools\\\\build_interaction.py</span> 重新生成单文件页）';""",
    """  $('hudDev').innerHTML = '学生版：改本文件「学生练习区」→ <span class="k">Ctrl+S</span> 保存 → ' +
    '<span class="k">F5</span> 刷新即可，无需构建。';""",
))

P01_TAIL_OLD = """<!-- __PROBE_ANCHOR__（若用「服务端注入探针」方案，探针脚本插在这里；当前用 puppeteer 直接 evaluate，不需要注入） -->
</body>"""

P01_TAIL_NEW = """<!-- __PROBE_ANCHOR__（若用「服务端注入探针」方案，探针脚本插在这里；当前用 puppeteer 直接 evaluate，不需要注入） -->

<!-- ===================== 学生练习区 · 文件末尾速查 =====================
     这是第 8 次课「学生课堂作业包」里的 01 交互实验室（学生版）。
       1) 双击本文件即可打开：不用服务器、不用联网、不用构建、不需要 Python/Node。
       2) PC 上就能玩：
            鼠标 = 瞄准 · 单击 = 选择/抓取/释放 · 拖拽 = 转头 · W A S D = 走动（Shift 快走）
            G = 抓取/释放 · T = 双手变换演示 · [ ] / 滚轮 = 两手间距 · P = Poke 直触
            H = 触觉模式 · 1/2/3 = 短/长/节奏 · R = 重置 · V = 检查器详略
       3) 三个目标看左上角清单：把方块吸进插槽 / 双手把能量球缩放到 2 倍 / Poke 直触按钮。
       4) 要改参数：Ctrl+F 搜「学生练习区」（在文件上部的主脚本注释块里，紧挨着参数）：
            SNAP_DIST（吸附半径，默认 0.30 m）· POKE_DIST（直触阈值，0.14 m）
            HAPTIC（触觉强度）· TRANS（状态机转移表）· makePokeButton（新增按钮）
          改完 Ctrl+S 保存 → 浏览器 F5 刷新 → 立刻生效。
       5) 改完没生效？按顺序查三件事：
            ① 编辑器里到底保存了没（记事本：标题栏没有“*”；VS Code：标题栏小圆点消失）
            ② 刷新的还是不是这个标签页（地址栏应以 学生课堂作业包/pages/01_交互实验室_学生版.html 结尾）
            ③ 改的是不是另一份副本（机房常见：从 zip 里直接双击的临时文件，改完解压还会被覆盖）
       6) 想确认参数真的生效：按 F12 → Console → 输入  __lab.limits()  回车，
          返回的 snapDist / pokeDist 就是你现在的值。
     ===================================================================== -->
</body>"""

# ============================ 02 模型工作台 ============================
P02 = []

P02.append((
    "02/标题",
    "<title>模型工作台 · WebXR（开发模板）</title>",
    "<title>02 模型工作台 · WebXR（学生版·单文件）</title>",
))

P02.append((
    "02/文件头注释",
    """<!--
  开发模板：src/02_模型工作台_template.html
  ─────────────────────────────────────────────────────────────
  这是「可编辑的开发版」：库用 ../lib/ 外部引用、模型用 fetch('../assets/models/*.glb')；
  双击本文件（file://）打不开模型（浏览器禁止 file:// fetch），请用 http 打开：
      cd demos && python -m http.server 8038
      http://127.0.0.1:8038/src/02_模型工作台_template.html
  改完运行：python tools/build_workbench.py
  构建脚本会把库与 4 个模型全部内联，生成 demos/02_模型工作台_WebXR.html（单文件、零外部请求）。
  ─────────────────────────────────────────────────────────────
-->""",
    """<!--
  学生版 · 单文件 · 零外部请求 · 双击即可用（file:// 不需要服务器）
  ─────────────────────────────────────────────────────────────
  本文件已把 4 个开源模型（Fox / CesiumMan / Duck / ArmChair_01）以 base64 内联，
  双击打开就能用：不需要 Python / Node / 服务器 / 网络 / 构建。
  要改参数：Ctrl+F 搜「学生练习区」（文件中部主脚本里的注释块），改完 Ctrl+S → F5 刷新。
  要换成自己下载的模型：用页面右侧「导入本机 GLB」按钮，不用改代码。
  ─────────────────────────────────────────────────────────────
-->""",
))

P02.append((
    "02/可见 meta 行",
    """  <div class="meta">模型来自开源站点（许可证见右侧卡片）· 单文件零外部请求
开发版：<code>src\\02_模型工作台_template.html</code>，改完运行 <code>python tools\\build_workbench.py</code> 重新生成单文件页</div>""",
    """  <div class="meta">模型来自开源站点（许可证见右侧卡片）· 单文件零外部请求 · 学生版：双击即可用，改「学生练习区」→ 保存 → 刷新</div>""",
))

P02.append((
    "02/练习2-A 文案",
    "// 练习2-A：改模型归一化高度（改 NORM_HEIGHT，默认 1.2 米；改完重新构建即可看到所有模型一起变高/变矮）",
    "// 练习2-A：改模型归一化高度（改 NORM_HEIGHT，默认 1.2 米；改完 Ctrl+S 保存 → F5 刷新，所有模型一起变高/变矮）",
))

P02.append((
    "02/加载失败提示",
    "（开发版请用 http 打开，见文件头注释）",
    "（本页模型已内联、无需服务器；请确认打开的是作业包 pages 目录里的这一份）",
))

P02.append((
    "02/BUILD_INFO 注释",
    "   构建脚本会把下面两个占位符（BUILD_INFO / MODELS_INLINE）替换成：构建信息 / 模型 base64",
    "   BUILD_INFO = 来源信息；MODELS_INLINE = 已内联的 4 个模型 base64（都是构建产物，学生机不用管、不用改）",
))

# ============================ 03 模型转换器 ============================
P03 = []

P03.append((
    "03/标题",
    "<title>模型转换器 · WebXR（开发模板）</title>",
    "<title>03 模型转换器 · WebXR（学生版·单文件）</title>",
))

P03.append((
    "03/文件头注释",
    """<!--
  开发模板：src/03_模型转换器_template.html
  ─────────────────────────────────────────────────────────────
  可编辑的开发版：库用 ../lib/ 外部引用；双击（file://）即可使用（不读本地模型文件，由用户拖入）。
  改完运行：python tools/build_workbench.py
  构建脚本会把全部库内联，生成 demos/03_模型转换器.html（单文件、零外部请求）。
  ─────────────────────────────────────────────────────────────
-->""",
    """<!--
  学生版 · 单文件 · 零外部请求 · 双击即可用
  ─────────────────────────────────────────────────────────────
  双击打开就能用：不需要 Python / Node / 服务器 / 网络 / 构建。
  把 .glb / .gltf(+.bin+贴图) / .obj / .fbx 拖进页面 → 自动解析统计 → 点「导出 GLB」下载。
  解析与导出都在本机浏览器里完成，文件不会上传到任何服务器。
  要改参数：Ctrl+F 搜「学生练习区」，改完 Ctrl+S → F5 刷新。
  ─────────────────────────────────────────────────────────────
-->""",
))

P03.append((
    "03/可见 meta 行",
    """    <div class="meta">开发版：<code>src\\03_模型转换器_template.html</code>，改完运行 <code>python tools\\build_workbench.py</code> 重新生成单文件页</div>""",
    """    <div class="meta">学生版：单文件零外部请求 · 双击即可用 · 解析与导出都在本机浏览器完成，不上传</div>""",
))

P03.append((
    "03/BUILD_INFO 注释",
    "   构建脚本会把 BUILD_INFO 占位符替换成构建信息",
    "   BUILD_INFO = 来源信息（构建产物，学生机不用管、不用改）",
))


def build_one(src, dst, patches, tail=None, tail_old=None):
    log("")
    log("=== %s" % os.path.basename(dst))
    raw, text = read_text(src)
    exp_bytes, exp_sha = EXPECT[src]
    log("   源：%s" % src)
    log("   源字节数 %d（期望 %s，%s）" % (len(raw), exp_bytes, "一致" if str(len(raw)) == exp_bytes else "不一致！"))
    if exp_sha:
        got = sha256(raw)
        log("   源 SHA-256 %s（%s）" % (got, "与记录一致" if got == exp_sha else "与记录不一致！"))
    for tag, old, new in patches:
        text = apply(text, old, new, tag)
    if tail_old:
        text = apply(text, tail_old, tail, "末段速查块")
    out = text.encode("utf-8")
    with open(dst, "wb") as f:
        f.write(out)
    log("   产出：%s" % dst)
    log("   产出字节数 %d（Δ %+d） SHA-256 %s" % (len(out), len(out) - len(raw), sha256(out)))
    return out


def scan_pages():
    log("")
    log("=== 学生页“不许出现”的指令式文案扫描 ===")
    bad = 0
    for path in (PAGE01_DST, PAGE02_DST, PAGE03_DST):
        text = open(path, encoding="utf-8").read()
        kept = text.count(PROVENANCE)
        body = text.replace(PROVENANCE, "")
        hits = [p for p in FORBIDDEN_IN_PAGES if p in body]
        name = os.path.basename(path)
        if hits:
            bad += 1
            log("   FAIL %s 命中：%s" % (name, ", ".join(hits)))
        else:
            note = ""
            if kept:
                note = "（BUILD_INFO 的来源字段 tools/build_workbench.py 保留 %d 处，属 provenance，非可执行指令）" % kept
            log("   PASS %s 未出现：%s%s" % (name, " / ".join(FORBIDDEN_IN_PAGES), note))
    return bad


def scan_zero_external():
    """零外部引用自检：不许有 <script src=、不许有 http(s):// 资源引用、不许有 url(http。"""
    log("")
    log("=== 三页“单文件零外部引用”静态自检 ===")
    import re
    pats = [
        ("<script src=", re.compile(r"<script[^>]+src\s*=", re.I)),
        ("<link href=非data", re.compile(r"<link[^>]+href\s*=\s*\"(?!data:)", re.I)),
        ("CSS url(非data)", re.compile(r"(?<![A-Za-z0-9_])url\(\s*['\"]?(?!data:|#)[^)]+\)")),
        ("CSS @import", re.compile(r"@import")),
        ("src=非data", re.compile(r"\bsrc\s*=\s*\"(?!data:)", re.I)),
    ]
    bad = 0
    for path in (PAGE01_DST, PAGE02_DST, PAGE03_DST):
        text = open(path, encoding="utf-8").read()
        name = os.path.basename(path)
        found = []
        for label, rx in pats:
            m = rx.findall(text)
            if m:
                found.append("%s×%d" % (label, len(m)))
        # 允许出现的：注释里的链接（http:// 文本）与 license URL，不算“外部请求”
        http_in_tags = re.findall(r"<(?:img|script|iframe|video|audio|source|object|embed)[^>]+https?://", text, re.I)
        if http_in_tags:
            found.append("标签内 http 资源×%d" % len(http_in_tags))
        if found:
            bad += 1
            log("   FAIL %s：%s" % (name, "；".join(found)))
        else:
            log("   PASS %s：无 <script src>、无外链 <link>、无 CSS 外部 url、无标签内 http 资源" % name)
    return bad


def main():
    log("=" * 78)
    log("生成学生版三页（只改说明性文字；代码逻辑零改动）")
    log("=" * 78)
    log("python : %s" % sys.version.replace("\n", " "))
    log("cwd    : %s" % os.getcwd())
    log("demos  : %s" % DEMOS)
    log("pages  : %s" % PAGES)

    for p in (PAGE01_SRC, PAGE02_SRC, PAGE03_SRC):
        if not os.path.isfile(p):
            log("!! 缺少源文件：%s" % p)
            raise SystemExit(3)

    build_one(PAGE01_SRC, PAGE01_DST, P01, P01_TAIL_NEW, P01_TAIL_OLD)
    build_one(PAGE02_SRC, PAGE02_DST, P02)
    build_one(PAGE03_SRC, PAGE03_DST, P03)

    bad = scan_pages() + scan_zero_external()

    log("")
    log("=" * 78)
    if bad:
        log("结果：FAIL（%d 项）" % bad)
        raise SystemExit(1)
    log("结果：PASS —— 三页已生成，文案无“需要构建”指令，单文件零外部引用")
    log("=" * 78)


if __name__ == "__main__":
    main()
