# -*- coding: utf-8 -*-
"""
build_worksheet_print.py —— 把 `01_作业单_90分钟_机房版.md` 转成可直接 Ctrl+P 双面打印的
单文件 `01_作业单_打印版.html`（A4 / 15mm 页边距 / 10.5pt / 表格不拆页 / 每页页眉带姓名学号栏 / 勾选框 ☐）。

只依赖 Python 标准库（机房与教师机都不需要 Pandoc / Word / 网络）。
支持的 Markdown 子集 = 本作业单实际用到的全部结构：
  标题(#~####)、段落、引用(>)、GFM 表格、无序列表(-)、任务列表(- [ ])、有序列表(1.)、
  代码块(```)、分隔线(---)、行内 **粗体** / `代码` / [链接](url)。
转换纪律：
  · 表格 → <table>（表头 <th>，正文 <td>），tbody 行不拆页；
  · 任务列表 - [ ] → <li class="check">（CSS 伪元素画 ☐，正文里也真的写一个 ☐ 以便纯文本可读）；
  · 代码片段里的 `\\\\` 折成 `\\`（Windows 路径在纸上更好读）；其余文字一律转义，不解释 HTML。

用法：
  C:\\Users\\Legion\\AppData\\Local\\Programs\\Python\\Python314\\python.exe build_worksheet_print.py
"""
import html
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
MD = os.path.join(PKG, "01_作业单_90分钟_机房版.md")
OUT = os.path.join(PKG, "01_作业单_打印版.html")

CSS = """
@page { size: A4 portrait; margin: 16mm 15mm 14mm 15mm; }
* { box-sizing: border-box; }
html, body { margin: 0; padding: 0; }
body {
  font-family: "Microsoft YaHei", "PingFang SC", "Source Han Sans SC", "Noto Sans CJK SC", serif;
  font-size: 10.5pt; line-height: 1.6; color: #111; background: #fff;
}
.screen-only { background: #eef4ff; border: 1px solid #9cbcff; border-radius: 6px;
  padding: 8px 12px; margin: 10px 0; font-size: 9.5pt; color: #1b3a6b; }
h1 { font-size: 17pt; margin: 0 0 8pt; line-height: 1.35; }
h2 { font-size: 13pt; margin: 15pt 0 6pt; padding-bottom: 3pt; border-bottom: 1.2pt solid #333;
  page-break-after: avoid; break-after: avoid; }
h3 { font-size: 11.5pt; margin: 11pt 0 4pt; page-break-after: avoid; break-after: avoid; }
h4 { font-size: 10.5pt; margin: 9pt 0 3pt; page-break-after: avoid; break-after: avoid; }
p { margin: 4pt 0; }
blockquote { margin: 5pt 0; padding: 4pt 7pt; border-left: 2.5pt solid #999; background: #f6f6f6;
  font-size: 9.8pt; page-break-inside: avoid; break-inside: avoid; }
blockquote p { margin: 2pt 0; }
ul, ol { margin: 4pt 0 7pt; padding-left: 17pt; }
li { margin: 1.5pt 0; }
ul.check { list-style: none; padding-left: 2pt; }
ul.check > li { margin: 2pt 0 2pt 0; text-indent: -13pt; padding-left: 13pt; }
ul.check > li::before { content: "\\2610  "; font-size: 11.5pt; }
table { width: 100%; border-collapse: collapse; margin: 5pt 0 9pt; font-size: 9.3pt;
  page-break-inside: avoid; break-inside: avoid; }
th, td { border: 0.6pt solid #666; padding: 2.5pt 4pt; vertical-align: top; text-align: left; }
th { background: #ececec; font-weight: 600; }
tr { page-break-inside: avoid; break-inside: avoid; }
code { font-family: Consolas, "Courier New", monospace; font-size: 9.2pt;
  background: #f1f1f1; padding: 0 1.5pt; border-radius: 2pt; }
pre { background: #f4f4f4; border: 0.6pt solid #ccc; border-radius: 3pt; padding: 5pt 7pt;
  font-family: Consolas, "Courier New", monospace; font-size: 8.8pt; line-height: 1.45;
  overflow-x: auto; page-break-inside: avoid; break-inside: avoid; white-space: pre-wrap; }
pre code { background: none; padding: 0; }
hr { border: none; border-top: 0.7pt dashed #999; margin: 9pt 0; }
a { color: #1144aa; text-decoration: none; }
strong { font-weight: 700; }

/* 每页页眉：position:fixed 在 Chrome 打印时会在每一页重复 */
.phead { display: none; }
@media print {
  .screen-only { display: none !important; }
  .phead {
    display: block; position: fixed; top: -11mm; left: 0; right: 0; height: 9mm;
    font-size: 8.6pt; color: #333; border-bottom: 0.5pt solid #999; padding-bottom: 1mm;
    background: #fff;
  }
  .phead .l { float: left; }
  .phead .r { float: right; }
  .phead .fill { letter-spacing: 0.5pt; }
  a { color: #111; }
  h1, h2, h3, h4 { color: #000; }
}
@media screen {
  body { max-width: 190mm; margin: 8mm auto; padding: 0 4mm; }
  .phead { display: none; }
}
"""

PHEAD = (
    '<div class="phead">'
    '<span class="l">第 8 次课 · 虚拟现实技术 · 646 机房 · 90′ 自主作业（2026-10-28）</span>'
    '<span class="r fill">姓名：__________　学号：____________　机位：______</span>'
    '</div>'
)

SCREEN_NOTE = (
    '<div class="screen-only"><b>打印说明（此提示不会被打印）</b>：浏览器 Ctrl+P → 纸张 <b>A4</b> → '
    '边距<b>默认</b> → 勾选<b>双面打印（短边翻页）</b> → 缩放 100%。'
    '本页已内置打印样式：正文 10.5pt、页边距 15–16mm、表格不拆页、每页页眉带姓名学号栏。</div>'
)


# ---------------------------------------------------------------- inline ----
def inline(text):
    """行内样式：先抽出 `code` 占位，再转义，再处理 **粗体** / [链接](url)。"""
    codes = []

    def stash(m):
        codes.append('<code>%s</code>' % html.escape(m.group(1).replace("\\\\", "\\")))
        return "\x00%d\x00" % (len(codes) - 1)

    text = re.sub(r"`([^`]+)`", stash, text)
    text = html.escape(text, quote=False)
    text = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", text)
    text = re.sub(r"\[([^\]]+)\]\(([^)\s]+)\)", r'<a href="\2">\1</a>', text)

    def unstash(m):
        return codes[int(m.group(1))]

    text = re.sub("\x00(\\d+)\x00", unstash, text)
    return text


# ---------------------------------------------------------------- blocks ----
def split_row(line):
    s = line.strip()
    if s.startswith("|"):
        s = s[1:]
    if s.endswith("|"):
        s = s[:-1]
    cells, buf, esc = [], [], False
    for ch in s:
        if esc:
            buf.append(ch)
            esc = False
        elif ch == "\\":
            buf.append(ch)
            esc = True
        elif ch == "|":
            cells.append("".join(buf).strip())
            buf = []
        else:
            buf.append(ch)
    cells.append("".join(buf).strip())
    return cells


TABLE_SEP = re.compile(r"^\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$")


def is_table_sep(line):
    s = line.strip()
    return bool(TABLE_SEP.match(s)) and "-" in s and s.count("|") >= 1


def convert(md):
    lines = md.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    out = []
    i = 0
    n = len(lines)
    stats = {"h": 0, "table": 0, "row": 0, "check": 0, "ul": 0, "ol": 0,
             "quote": 0, "pre": 0, "hr": 0, "p": 0}

    def flush_para(buf):
        if buf:
            out.append("<p>%s</p>" % inline(" ".join(x.strip() for x in buf)))
            stats["p"] += 1
            buf.clear()

    while i < n:
        line = lines[i]
        s = line.strip()

        # 空行
        if not s:
            i += 1
            continue

        # 代码块
        if s.startswith("```"):
            i += 1
            body = []
            while i < n and not lines[i].strip().startswith("```"):
                body.append(lines[i])
                i += 1
            i += 1  # 跳过结束 ```
            out.append("<pre><code>%s</code></pre>" % html.escape("\n".join(body)))
            stats["pre"] += 1
            continue

        # 分隔线
        if re.match(r"^-{3,}\s*$", s):
            out.append("<hr>")
            stats["hr"] += 1
            i += 1
            continue

        # 标题
        m = re.match(r"^(#{1,6})\s+(.*)$", s)
        if m:
            lvl = min(len(m.group(1)), 4)
            out.append("<h%d>%s</h%d>" % (lvl, inline(m.group(2)), lvl))
            stats["h"] += 1
            i += 1
            continue

        # 表格：当前行含 |，下一行是分隔行
        if "|" in s and i + 1 < n and is_table_sep(lines[i + 1]):
            header = split_row(s)
            i += 2
            rows = []
            while i < n and lines[i].strip().startswith("|"):
                rows.append(split_row(lines[i]))
                i += 1
            cols = len(header)
            t = ["<table>", "<thead><tr>"]
            for c in header:
                t.append("<th>%s</th>" % inline(c))
            t.append("</tr></thead><tbody>")
            for r in rows:
                if len(r) < cols:
                    r = r + [""] * (cols - len(r))
                t.append("<tr>" + "".join("<td>%s</td>" % inline(c) for c in r[:cols]) + "</tr>")
            t.append("</tbody></table>")
            out.append("\n".join(t))
            stats["table"] += 1
            stats["row"] += len(rows)
            continue

        # 引用块（连续 > 行合并成一个 blockquote）
        if s.startswith(">"):
            q = []
            while i < n and lines[i].strip().startswith(">"):
                q.append(re.sub(r"^\s*>\s?", "", lines[i]).rstrip())
                i += 1
            paras = "\n".join(q).split("\n\n")
            inner = []
            for p in paras:
                chunk = [x for x in p.split("\n") if x.strip()]
                if not chunk:
                    continue
                inner.append("<p>%s</p>" % "<br>".join(inline(x) for x in chunk))
            out.append("<blockquote>%s</blockquote>" % "\n".join(inner))
            stats["quote"] += 1
            continue

        # 任务列表 - [ ] / - [x]
        if re.match(r"^[-*+]\s+\[[ xX]\]\s*", s):
            items = []
            while i < n and re.match(r"^[-*+]\s+\[[ xX]\]\s*", lines[i].strip()):
                body = re.sub(r"^[-*+]\s+\[[ xX]\]\s*", "", lines[i].strip())
                items.append(body)
                i += 1
            out.append('<ul class="check">')
            for it in items:
                out.append('<li>%s</li>' % inline(it))
            out.append("</ul>")
            stats["check"] += len(items)
            stats["ul"] += 1
            continue

        # 无序列表
        if re.match(r"^[-*+]\s+", s):
            items = []
            while i < n and re.match(r"^[-*+]\s+", lines[i].strip()) \
                    and not re.match(r"^[-*+]\s+\[[ xX]\]\s*", lines[i].strip()):
                items.append(re.sub(r"^[-*+]\s+", "", lines[i].strip()))
                i += 1
            out.append("<ul>")
            for it in items:
                out.append("<li>%s</li>" % inline(it))
            out.append("</ul>")
            stats["ul"] += 1
            continue

        # 有序列表
        if re.match(r"^\d+[.)]\s+", s):
            items = []
            while i < n and re.match(r"^\d+[.)]\s+", lines[i].strip()):
                items.append(re.sub(r"^\d+[.)]\s+", "", lines[i].strip()))
                i += 1
            out.append("<ol>")
            for it in items:
                out.append("<li>%s</li>" % inline(it))
            out.append("</ol>")
            stats["ol"] += 1
            continue

        # 段落（吃到空行 / 下一个块级结构前）
        buf = [line]
        i += 1
        while i < n:
            nxt = lines[i]
            ns = nxt.strip()
            if (not ns) or ns.startswith("#") or ns.startswith(">") or ns.startswith("```") \
                    or ns.startswith("|") or re.match(r"^[-*+]\s+", ns) \
                    or re.match(r"^\d+[.)]\s+", ns) or re.match(r"^-{3,}\s*$", ns):
                break
            buf.append(nxt)
            i += 1
        flush_para(buf)

    return "\n".join(out), stats


def main():
    if not os.path.isfile(MD):
        print("!! 缺少作业单 Markdown：%s" % MD)
        raise SystemExit(2)
    md = open(MD, encoding="utf-8").read()
    body, stats = convert(md)
    title = "第 8 次课 · 学生课堂练习单（646 机房 · 90′ 自主作业）"
    m = re.search(r"^#\s+(.+)$", md, re.M)
    if m:
        title = m.group(1).strip()

    doc = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>%s（打印版）</title>
<style>%s</style>
</head>
<body>
%s
%s
%s
</body>
</html>
""" % (html.escape(title), CSS, PHEAD, SCREEN_NOTE, body)

    with open(OUT, "w", encoding="utf-8", newline="\n") as f:
        f.write(doc)

    data = doc.encode("utf-8")
    print("源 MD : %s (%d B, %d 行)" % (MD, os.path.getsize(MD), md.count("\n") + 1))
    print("输出  : %s (%d B)" % (OUT, len(data)))
    print("统计  : 标题 %(h)d ｜ 表格 %(table)d 个 / %(row)d 行 ｜ 勾选框 %(check)d ｜ "
          "无序表 %(ul)d ｜ 有序表 %(ol)d ｜ 引用 %(quote)d ｜ 代码块 %(pre)d ｜ 分隔线 %(hr)d ｜ 段落 %(p)d" % stats)
    # 自检：不许出现外部引用
    bad = []
    if re.search(r"<script", doc, re.I):
        bad.append("<script>")
    if re.search(r"<(?:link|img|iframe)[^>]+(?:href|src)\s*=\s*\"(?!#)", doc, re.I):
        bad.append("外链资源")
    if re.search(r"@import", doc):
        bad.append("@import")
    print("自检  : 无 <script> / 无外链资源 / 无 @import -> %s" % ("PASS" if not bad else "FAIL：" + ",".join(bad)))
    if bad:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
