# ArmChair_01.glb — 许可与署名

| 项 | 值 |
|---|---|
| 文件 | `demos/assets/models/ArmChair_01.glb`（768,568 B） |
| SHA-256 | `69f267da2a5f4373a37d5aca3f9c7ab242438e27eba912443c1516038b6a62fd` |
| 几何 | 5,626 三角面 / 3,758 顶点 / 1 网格 / 1 材质（doubleSided）/ **3 纹理(JPEG)** / **0 动画** / 1 节点 |
| 作者 | **Kirill Sannikov**（Poly Haven API `info/ArmChair_01` 的 `authors` 字段：`{"Kirill Sannikov": "All"}`） |
| 站点 | https://polyhaven.com/a/ArmChair_01 |
| 许可页 | https://polyhaven.com/license |
| 文件 API | https://api.polyhaven.com/files/ArmChair_01 |
| 信息 API | https://api.polyhaven.com/info/ArmChair_01 |

## 一、许可：CC0 1.0 Universal（Public Domain）

| 项 | 值 |
|---|---|
| 许可 | **CC0 1.0 Universal** |
| 可商用 | ✅ 是 |
| 需署名 | ❌ **不要求**（署名是礼节，不是义务） |
| 可再分发 | ✅ 是，可打包进产品、可转卖作品 |

## 二、源站原文片段（polyhaven.com/license）

```
All assets (HDRIs, textures and 3D models) on this site are the original work of Poly Haven staff,
or artists who willingly and directly donate/sell their work to Poly Haven.

Our assets are all licensed as CC0, which is effectively Public Domain even in jurisdictions that
do not support the Public Domain.
```

```
In other words:
- You can use our assets for any purpose, including commercial work.
- You do not need to give credit or attribution when using them (although it is appreciated).
- You can redistribute them, share them around, include them when sharing your own work,
  or even in a product you sell.
```

资产页自己的描述（API `info/ArmChair_01` 的 `description`）也写着：

```
Free (CC0) vintage Victorian armchair 3D model - varnished carved wood frame, upholstered seat;
gothic/classic styling ideal for interiors, period scenes, and renders.
```

## 三、这个 GLB 是怎么来的（可复现，已实测字节级一致）

它不是直接从 Poly Haven 下载的现成 GLB —— Poly Haven 提供的是 **`.gltf` + `.bin` + 分分辨率纹理**，
本文件是**转出来的**：

```
Poly Haven ArmChair_01 @1k
        │  api.polyhaven.com/files/ArmChair_01  →  拿 gltf / bin / 3 张 jpg 的 URL
        ▼
ArmChair_01_1k.gltf (2,643B) + ArmChair_01.bin (154,012B) + textures/*.jpg ×3
        │  gltf-pipeline 4.3.1
        ▼
ArmChair_01.glb (768,568B)   ← demos/assets/models/ArmChair_01.glb
```

**转换命令（一条）**：

```powershell
gltf-pipeline -i ArmChair_01_1k.gltf -o ArmChair_01.glb
```

**可复现性证据（实测，非估算）**：

| 项 | 值 |
|---|---|
| 源文件 5 个的 MD5 与 Poly Haven API 返回的 `md5` 字段 | **逐一相等** |
| 复转输出字节数 | 768,568 B（与交付文件相同） |
| 复转输出 SHA-256 | `69f267da2a5f4373a37d5aca3f9c7ab242438e27eba912443c1516038b6a62fd` |
| 与交付文件对比 | **完全相同（byte-identical）** |

> 细节：如果转换时改了输出文件名（比如 `-o ArmChair_01_reconverted.glb`），只有 GLB 里
> `buffers[0].name` 会和 JSON chunk 的 4 字节对齐填充一起变（实测 768,584 B，差 16 字节），
> **几何、材质、纹理会完全一样**（三角面 5,626 / 顶点 3,758 / 纹理 3）。文件名别改就字节级一致。

源文件清单（MD5 与 API 对得上）：

| 文件 | 字节 | MD5 |
|---|---|---|
| `ArmChair_01_1k.gltf` | 2,643 | `39d1e4b0ffdde688c98335c9621e3aae` |
| `ArmChair_01.bin` | 154,012 | `fbd842795fdec75d94f1335c28acfc0e` |
| `textures/Armchair_01_diff_1k.jpg`（基础色） | 184,246 | `9166f2c24f2114a5fa5513950ed9b9ae` |
| `textures/Armchair_01_nor_gl_1k.jpg`（法线） | 289,916 | `8541821edd6dcb319b7f9841d849fbbe` |
| `textures/Armchair_01_arm_1k.jpg`（金属度/粗糙度打包） | 138,327 | `2ea528244dd6fc0deb2af1a555c0a312` |

> 这两张表就是课堂「**下载 → 校验 → 转换**」的标准动作：下载完先对 MD5/SHA-256，再转换，再验 GLB 头。

## 四、可直接粘贴的署名文本（CC0 不要求，写上是礼节）

```
模型：ArmChair_01（维多利亚风格扶手椅）
- 作者：Kirill Sannikov / Poly Haven
- 许可：CC0 1.0 Universal（公共领域，可商用，不要求署名）
- 来源：https://polyhaven.com/a/ArmChair_01
- 处理：由 Poly Haven 的 glTF 1k 版本经 gltf-pipeline 转 GLB
```

## 五、许可全文链接

- CC0 1.0：https://creativecommons.org/publicdomain/zero/1.0/legalcode
- Poly Haven 许可页：https://polyhaven.com/license

## 六、课堂可用性

✅ **可用，且是四个内嵌模型里最省事的一个**（CC0，连署名都不要求）。
用途：`02_模型工作台_WebXR.html` 的内嵌静态模型；同时是 `demos/tools/download_pipeline.md` 里
「Poly Haven → gltf-pipeline → GLB」整条流水线的实物样本。

> 注意 Poly Haven 的 ToS §3.2 禁止「未经许可的网页抓取/数据挖掘」，
> 但它的**公开 API 是明确提供给学生/研究者用的**（另有 API Terms，见 `download_pipeline.md`）。
> 课堂上请走 API，不要暴力爬站。
