# -*- coding: utf-8 -*-
"""
pages_file_selfcheck.py —— 三页（01 学生版 / 02 模型工作台 / 03 模型转换器）在
`file://` 双击场景下的真实自测：能不能启动、有没有报错、API 在不在、运行时有没有外部请求。

每页做两件事：
  A. 顶层直开：让 Chrome 直接把页面当主文档打开（等价学生双击），`--dump-dom` 抓 DOM，
     检查标题/启动痕迹/没有「启动失败」；
  B. 探针读取：探针页 iframe 打开同一文件（file:// 同源，加 --allow-file-access-from-files），
     读 `window.__errs`、页面自己的 API（__lab / __workbench / __converter）、
     以及 `performance.getEntriesByType('resource')`（运行时真实请求清单）。

零依赖：Python 标准库 + 本机 Chrome。用法：
  C:\\Users\\Legion\\AppData\\Local\\Programs\\Python\\Python314\\python.exe pages_file_selfcheck.py
"""
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import skheadless as H  # noqa: E402

OUT_TXT = os.path.join(HERE, "pages_file_selfcheck.txt")

PAGES = [
    {
        "key": "01",
        "file": os.path.join(PKG, "pages", "01_交互实验室_学生版.html"),
        "title_has": "01 交互实验室 · WebXR 交互进阶（学生版·单文件）",
        "boot_marker": "第 8 次课 Part 1",
        "label": "01 交互实验室（学生版·单文件）",
        "extract": r"""
  var L = w.__lab;
  r.apiName = '__lab';
  r.apiExists = !!L;
  if (!L) { r.__pending = true; return {}; }
  r.apiKeys = Object.keys(L).sort();
  r.ready = !!L.ready();
  r.limits = L.limits();
  r.goalsDone = L.goals().done;
  r.goalsTotal = L.goals().total;
  r.hudDev = (d.getElementById('hudDev') || {}).textContent || null;
  r.hudTag = (d.getElementById('hudTag') || {}).textContent || null;
  r.hudPc = (d.getElementById('hudPC') || {}).textContent || null;
  r.canvas = (function(){ var c = d.getElementById('c'); return c ? c.width + 'x' + c.height : null; })();
  r.__pending = false;
  return {};
""",
    },
    {
        "key": "02",
        "file": os.path.join(PKG, "pages", "02_模型工作台_WebXR.html"),
        "title_has": "02 模型工作台 · WebXR（学生版·单文件）",
        "boot_marker": "模型工作台",
        "label": "02 模型工作台（学生版·单文件）",
        "extract": r"""
  var W = w.__workbench;
  r.apiName = '__workbench';
  r.apiExists = !!W;
  if (!W) { r.__pending = true; return {}; }
  r.apiKeys = Object.keys(W).sort();
  var list = [];
  try { list = W.list() || []; } catch (e) { r.listError = String((e && e.message) || e); }
  r.modelCount = list.length;
  r.modelNames = list.map(function(m){ return (m && (m.name || m.id)) || '?'; });
  r.modelBytes = list.map(function(m){ return m && m.bytes; });
  var sb = d.getElementById('statbar');
  r.statbar = sb ? String(sb.textContent).trim() : null;
  var meta = d.querySelector('#hud .meta');
  r.meta = meta ? String(meta.textContent).trim() : null;
  r.__pending = (r.modelCount < 4);
  return {};
""",
    },
    {
        "key": "03",
        "file": os.path.join(PKG, "pages", "03_模型转换器.html"),
        "title_has": "03 模型转换器 · WebXR（学生版·单文件）",
        "boot_marker": "模型转换器",
        "label": "03 模型转换器（学生版·单文件）",
        "extract": r"""
  var C = w.__converter;
  r.apiName = '__converter';
  r.apiExists = !!C;
  if (!C) { r.__pending = true; return {}; }
  r.apiKeys = Object.keys(C).sort();
  r.version = (typeof C.version !== 'undefined') ? C.version : null;
  r.ready = (typeof C.ready === 'boolean') ? C.ready : null;
  var meta = d.querySelector('#hud .meta');
  r.meta = meta ? String(meta.textContent).trim() : null;
  var drop = d.getElementById('dropzone');
  r.dropzone = drop ? String(drop.textContent).replace(/\s+/g, ' ').trim() : null;
  r.__pending = (C.ready === false);
  return {};
""",
    },
]

lines = []
ok_all = True


def log(s=""):
    print(s)
    lines.append(s)


def rule(ch="="):
    log(ch * 78)


def main():
    global ok_all
    rule()
    log("三页 file:// 自测报告（学生课堂作业包 / pages）")
    log("生成时间：%s" % __import__("datetime").datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    rule()
    log("【环境】")
    log("  python : %s" % sys.version.replace("\n", " "))
    log("  chrome : %s（存在=%s）" % (H.CHROME, os.path.isfile(H.CHROME)))
    log("  包目录 : %s" % PKG)
    log("  方法   : 无头 Chrome --headless=new --dump-dom；取值走 _verify/skheadless.py 的探针页 iframe")
    log("           （加 --allow-file-access-from-files 才能跨 file:// 读 contentWindow；不需要 node_modules）")

    for p in PAGES:
        rule("-")
        log("【%s】%s" % (p["key"], p["label"]))
        log("  文件：%s" % p["file"])
        if not os.path.isfile(p["file"]):
            ok_all = False
            log("  !! 文件不存在")
            continue
        size = os.path.getsize(p["file"])
        log("  大小：%d B（%.1f KB）" % (size, size / 1024.0))
        with open(p["file"], "rb") as f:
            head = f.read(4096).decode("utf-8", "replace")
        log("  <!DOCTYPE html> 开头：%s" % ("PASS" if head.lstrip().startswith("<!DOCTYPE html>") else "FAIL"))
        log("  标题标签：%s" % ("PASS" if ("<title>" + p["title_has"] in head.replace("\r", "")) else
                              "WARN（<title> 不在前 4KB 或文案不同）"))

        # A. 顶层直开
        log("  --- A. 顶层直开（学生双击同款）：--dump-dom ---")
        rc, dom, ms, cmd = H.dump_dom(H._uri(p["file"]), timeout=180)
        log("      CMD : %s" % cmd)
        log("      RC  : %s   耗时 %.0f ms   DOM %d 字符" % (rc, ms, len(dom)))
        title = re.search(r"<title>(.*?)</title>", dom, re.S)
        title = title.group(1) if title else None
        log("      title          : %r → %s" % (title, "PASS" if title == p["title_has"] else "FAIL"))
        boot = p["boot_marker"] in dom
        log("      启动痕迹关键串 : %r → %s" % (p["boot_marker"], "PASS" if boot else "FAIL"))
        m = re.search(r'<p id="loadMsg">([^<]*)</p>', dom)
        load_msg = m.group(1) if m else None
        boot_fail = bool(load_msg and load_msg.startswith("启动失败"))
        log("      loadMsg        : %r → %s" % (load_msg, "FAIL（启动失败）" if boot_fail else "PASS"))
        has_hud = 'id="hud"' in dom or 'id="hud"' in dom
        log("      HUD 容器存在   : %s" % ("PASS" if has_hud else "WARN"))
        step_ok = (rc == 0 and title == p["title_has"] and boot and not boot_fail)
        ok_all = ok_all and step_ok
        log("      A 判定         : %s" % ("PASS" if step_ok else "FAIL"))

        # B. 探针读取
        log("  --- B. 探针读取运行时状态（file:// iframe）---")
        res = H.probe(H._uri(p["file"]), p["extract"], wait_ms=4000, budget_ms=6000, timeout=180)
        log("      CMD : %s" % res["_cmd"])
        log("      RC  : %s   耗时 %.0f ms" % (res["_rc"], res["_elapsed_ms"]))
        if "_error" in res:
            ok_all = False
            log("      !! %s" % res["_error"])
            continue
        log("      readyState     : %r" % res.get("readyState"))
        log("      errs（__errs）  : %r → %s" % (res.get("errs"),
                                                  "PASS（空）" if not res.get("errs") else "FAIL"))
        log("      API %-12s: 存在=%s keys=%s" % (res.get("apiName"), res.get("apiExists"),
                                                ",".join(res.get("apiKeys") or [])[:160]))
        if res.get("apiName") == "__lab":
            log("      ready          : %r" % res.get("ready"))
            log("      limits         : %r" % (res.get("limits"),))
            log("      goals          : %s/%s" % (res.get("goalsDone"), res.get("goalsTotal")))
            log("      hudDev         : %r" % res.get("hudDev"))
            log("      canvas         : %r" % res.get("canvas"))
        elif res.get("apiName") == "__workbench":
            log("      modelCount     : %r" % res.get("modelCount"))
            log("      modelNames     : %r" % (res.get("modelNames"),))
            log("      modelBytes     : %r" % (res.get("modelBytes"),))
            log("      statbar        : %r" % res.get("statbar"))
            log("      meta           : %r" % res.get("meta"))
        else:
            log("      version        : %r" % res.get("version"))
            log("      ready          : %r" % res.get("ready"))
            log("      meta           : %r" % res.get("meta"))
            log("      dropzone       : %r" % res.get("dropzone"))
        # 运行时请求：证明没有外部网络请求
        reqs = res.get("resourceEntries") or []
        http = [u for u in reqs if str(u).startswith(("http://", "https://"))]
        log("      运行时资源请求 : %d 条（其中 http/https %d 条）→ %s"
            % (len(reqs), len(http), "PASS（零外部请求）" if not http else "FAIL"))
        for u in http[:5]:
            log("        !! 外部请求 %s" % u)
        if http:
            ok_all = False

        api_ok = bool(res.get("apiExists")) and not res.get("errs")
        if res.get("apiName") == "__lab":
            api_ok = api_ok and bool(res.get("ready")) and (res.get("goalsTotal") == 3)
        elif res.get("apiName") == "__workbench":
            api_ok = api_ok and (res.get("modelCount") or 0) >= 1
        else:
            api_ok = api_ok and (res.get("ready") is not False)
        ok_all = ok_all and api_ok
        log("      B 判定         : %s" % ("PASS" if api_ok else "FAIL"))

    rule()
    log("【结论】")
    log("  三页 file:// 单文件零外部引用 + 运行时无外部请求 + 各自 API 可用：%s"
        % ("PASS" if ok_all else "FAIL"))
    log("")
    log("【诚实边界 · 未验证】")
    log("  · 只用 headless Chrome + SwiftShader 软件渲染验证；真实机房显卡/浏览器版本渲染速度会不同")
    log("  · 没有真机头显/手柄：VR 会话进入、手柄扳机/握持、触觉执行器、双手同时抓取的手势识别均未真机验证")
    log("  · 没有真实鼠标拖拽/键盘事件注入（只验证页面 API 与 DOM 状态）")
    log("  · 02 的「本地导入 GLB」按钮需要真人点选文件对话框，headless 无法代点；功能逻辑已在教师机 demos 验证中覆盖")
    rule()

    with open(OUT_TXT, "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(lines) + "\n")
    print("\n报告已写入：%s" % OUT_TXT)
    return 0 if ok_all else 1


if __name__ == "__main__":
    sys.exit(main())
