# -*- coding: utf-8 -*-
"""
student_edit_check.py —— 证明「学生直接改单文件 HTML → 保存 → 刷新」这条链路真的成立。

做法（全部真实执行，报告里贴真实命令与真实输出）：
  1. 基线：用无头 Chrome（file://）打开 `pages/01_交互实验室_学生版.html`，
     由探针页读回 `window.__lab.limits().snapDist` —— 期望 0.30。
  2. 编辑：用**正则**把 `var SNAP_DIST = 0.30;` 改成 `var SNAP_DIST = 0.45;`，
     另存为临时文件（同时用 difflib 证明**只改了这一行**）。
  3. 刷新：用无头 Chrome（file://）打开临时文件，读回同一个值 —— 必须 = 0.45。
  4. 直开：再对临时文件跑一次 `--dump-dom`（学生双击同款路径），证明页面能正常启动。
  5. 收尾：删除临时文件，并复查基线文件仍是 0.30（学生盘上的原件没被改坏）。

零依赖：只用 Python 标准库 + 本机 Chrome（不需要 node_modules / puppeteer）。
用法：
  C:\\Users\\Legion\\AppData\\Local\\Programs\\Python\\Python314\\python.exe student_edit_check.py
"""
import difflib
import os
import re
import shutil
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import skheadless as H  # noqa: E402

PAGE = os.path.join(PKG, "pages", "01_交互实验室_学生版.html")
OUT_TXT = os.path.join(HERE, "student_edit_check.txt")

OLD = "var SNAP_DIST = 0.30;"
NEW = "var SNAP_DIST = 0.45;"

# 在探针页里对目标页执行的取值脚本（参数 w=目标 window, d=目标 document, r=结果对象）
EXTRACT = r"""
  var L = w.__lab;
  r.labExists = !!L;
  if (!L) { r.__pending = true; return {}; }
  r.labReady = !!L.ready();
  var lim = L.limits();
  r.snapDist = lim.snapDist;
  r.pokeDist = lim.pokeDist;
  r.rayMax = lim.rayMax;
  r.handOffZ = lim.handOffZ;
  r.hapticMode = lim.hapticMode;
  r.hudDev = (d.getElementById('hudDev') || {}).textContent || null;
  r.hudTag = (d.getElementById('hudTag') || {}).textContent || null;
  r.goals = L.goals();
  r.__pending = false;
  return {};
"""

lines = []


def log(s=""):
    print(s)
    lines.append(s)


def rule(ch="="):
    log(ch * 78)


def read_page():
    with open(PAGE, "rb") as f:
        raw = f.read()
    return raw, raw.decode("utf-8")


def probe_target(uri, label):
    log("  CMD: python  _verify\\skheadless.py  ->  chrome --headless=new --allow-file-access-from-files "
        "--enable-unsafe-swiftshader --virtual-time-budget=25000 --dump-dom <探针页>")
    log("       探针页 iframe src = %s" % uri)
    res = H.probe(uri, EXTRACT, wait_ms=2500, budget_ms=3500,
                  keep=os.path.join(tempfile.gettempdir(), "skprobe_last_%s.html" % label))
    log("  CHROME_CMD : %s" % res["_cmd"])
    log("  CHROME_RC  : %s   耗时 %.0f ms" % (res["_rc"], res["_elapsed_ms"]))
    if "_error" in res:
        log("  !! %s" % res["_error"])
        return res
    for k in ("href", "readyState", "docTitle", "labExists", "labReady", "snapDist", "pokeDist",
              "rayMax", "hapticMode", "hudTag", "errs"):
        if k in res:
            log("  %-12s : %r" % (k, res.get(k)))
    g = res.get("goals") or {}
    log("  goals        : done=%s total=%s" % (g.get("done"), g.get("total")))
    log("  hudDev       : %r" % (res.get("hudDev"),))
    return res


def main():
    rule()
    log("学生可编辑性实测 · 01 交互实验室（学生版）")
    log("目标：证明「直接改单文件 HTML 里的参数 → 保存 → 刷新」这条链路成立（无需构建 / 无需服务器）")
    rule()
    log("【环境】")
    log("  python : %s" % sys.version.replace("\n", " "))
    log("  chrome : %s（存在=%s）" % (H.CHROME, os.path.isfile(H.CHROME)))
    log("  学生页 : %s" % PAGE)
    if not os.path.isfile(PAGE):
        log("!! 缺文件：%s" % PAGE)
        raise SystemExit(2)
    _, text = read_page()
    log("  页大小 : %d B" % len(text.encode("utf-8")))
    log("  原件里 `%s` 出现次数：%d（必须为 1）" % (OLD, text.count(OLD)))

    ok = True
    if text.count(OLD) != 1:
        log("!! 原件里找不到唯一锚点，无法做编辑测试")
        raise SystemExit(3)

    # ---------------- 1. 基线 ----------------
    log("")
    rule("-")
    log("【第 1 步】基线：未改动时读回 snapDist（期望 0.30）")
    rule("-")
    base = probe_target(H._uri(PAGE), "baseline")
    base_val = base.get("snapDist")
    if base.get("_error") or not base.get("labExists") or base_val is None:
        ok = False
        log("  BASELINE: FAIL（没读到 __lab.limits().snapDist）")
    elif abs(float(base_val) - 0.30) < 1e-9:
        log("  BASELINE: PASS  snapDist = %r（期望 0.30）" % base_val)
    else:
        ok = False
        log("  BASELINE: FAIL  snapDist = %r（期望 0.30）" % base_val)

    # ---------------- 2. 正则编辑 ----------------
    log("")
    rule("-")
    log("【第 2 步】模拟学生编辑：正则把 `%s` 改成 `%s`，另存临时文件" % (OLD, NEW))
    rule("-")
    edited, n = re.subn(r"var SNAP_DIST = 0\.30;", "var SNAP_DIST = 0.45;", text, count=1)
    log("  REGEX sub 命中 %d 处（re.subn count=1）" % n)
    if n != 1:
        log("  EDIT: FAIL")
        raise SystemExit(4)

    diff = [l for l in difflib.unified_diff(text.splitlines(), edited.splitlines(),
                                            "原件", "改后", lineterm="", n=0)
            if l.startswith(("+", "-")) and not l.startswith(("+++", "---"))]
    log("  DIFF（只允许 1 行 - / 1 行 +）：")
    for l in diff:
        log("    %s" % l)
    only_anchor = (len(diff) == 2 and diff[0].startswith("-") and OLD in diff[0]
                   and diff[1].startswith("+") and NEW in diff[1])
    log("  只改了这一行：%s" % ("PASS" if only_anchor else "FAIL"))
    ok = ok and only_anchor
    log("  改前 %d B → 改后 %d B（Δ %+d，两个数字一样长，字节数不变）"
        % (len(text.encode()), len(edited.encode()), len(edited.encode()) - len(text.encode())))

    tmpdir = tempfile.mkdtemp(prefix="sk_edit_")
    tmp_page = os.path.join(tmpdir, "01_交互实验室_学生版_临时改写.html")
    with open(tmp_page, "w", encoding="utf-8", newline="") as f:
        f.write(edited)
    log("  临时文件：%s（%d B）" % (tmp_page, os.path.getsize(tmp_page)))

    # ---------------- 3. “刷新”后读回 ----------------
    log("")
    rule("-")
    log("【第 3 步】打开临时文件（file://，等同学生保存后按 F5）再读回 snapDist（必须 = 0.45）")
    rule("-")
    ed = probe_target(H._uri(tmp_page), "edited")
    ed_val = ed.get("snapDist")
    if ed.get("_error") or not ed.get("labExists") or ed_val is None:
        ok = False
        log("  EDITED: FAIL（没读到 __lab.limits().snapDist）")
    elif abs(float(ed_val) - 0.45) < 1e-9:
        log("  EDITED: PASS  snapDist = %r（期望 0.45）" % ed_val)
    else:
        ok = False
        log("  EDITED: FAIL  snapDist = %r（期望 0.45）" % ed_val)

    log("  对比：基线 %r → 改后 %r（Δ = %s）"
        % (base_val, ed_val,
           (round(float(ed_val) - float(base_val), 4) if (base_val is not None and ed_val is not None) else "n/a")))
    log("  pokeDist 未动：基线 %r / 改后 %r（应相同）" % (base.get("pokeDist"), ed.get("pokeDist")))

    # ---------------- 4. 双击直开（不用探针） ----------------
    log("")
    rule("-")
    log("【第 4 步】学生“双击直开”同款路径：对临时文件直接 --dump-dom（不用探针页）")
    rule("-")
    rc, dom, ms, cmd = H.dump_dom(H._uri(tmp_page), timeout=120)
    log("  CHROME_CMD : %s" % cmd)
    log("  CHROME_RC  : %s   耗时 %.0f ms   DOM %d 字符" % (rc, ms, len(dom)))
    has_anchor = "var SNAP_DIST = 0.45;" in dom
    booted = ("第 8 次课 Part 1" in dom) and ("id=\"hudTitle\">01 交互实验室" in dom)
    m = re.search(r'<p id="loadMsg">([^<]*)</p>', dom)
    load_msg = m.group(1) if m else "(loadMsg 已被移除：启动成功后会淡出删除)"
    boot_ok = (m is None) or (not load_msg.startswith("启动失败"))
    log("  DOM 里源码锚点 `var SNAP_DIST = 0.45;`：%s" % ("PASS" if has_anchor else "FAIL"))
    log("  DOM 里 JS 启动痕迹（hudTitle/hudTag 已被 boot() 写入）：%s" % ("PASS" if booted else "FAIL"))
    log("  loadMsg 状态：%r → %s" % (load_msg, "PASS" if boot_ok else "FAIL"))
    ok = ok and has_anchor and booted and boot_ok

    # ---------------- 5. 收尾 ----------------
    log("")
    rule("-")
    log("【第 5 步】收尾：删临时文件 + 复查学生盘原件仍是 0.30")
    rule("-")
    shutil.rmtree(tmpdir, ignore_errors=True)
    log("  临时目录已删除：%s（还存在=%s）" % (tmpdir, os.path.exists(tmpdir)))
    _, text2 = read_page()
    still = text2.count(OLD) == 1
    log("  原件 `%s` 仍唯一存在：%s（原件字节数 %d，未改动）"
        % (OLD, "PASS" if still else "FAIL", len(text2.encode())))
    ok = ok and (not os.path.exists(tmpdir)) and still

    # ---------------- 结论 ----------------
    log("")
    rule()
    log("【结论】")
    log("  BASELINE_SNAPDIST : %r" % base_val)
    log("  EDITED_SNAPDIST   : %r" % ed_val)
    log("  RESULT            : %s" % ("PASS" if ok else "FAIL"))
    log("")
    log("【这条链路为什么对学生成立】")
    log("  1) 页面是单文件（three.js 内联），file:// 双击即可执行，不需要服务器/构建/Python/Node；")
    log("  2) 参数 `SNAP_DIST` 是普通 `var` 常量，学生用记事本改数字、Ctrl+S、F5 就生效；")
    log("  3) 本次实测：同一个文件只改这一行（0.30→0.45），页面运行时读回 0.45，没有被构建产物覆盖；")
    log("  4) 学生若改坏，重新从作业包 pages\\ 拷一份即可恢复。")
    log("")
    log("【未验证项】")
    log("  · 只在 headless Chrome + SwiftShader 软件渲染下验证；真实机房显卡/浏览器版本可能渲染快慢不同")
    log("  · 真机头显里的参数效果（双手/poke/吸附手感）需在 430 教室真机复测")
    rule()

    with open(OUT_TXT, "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(lines) + "\n")
    print("\n报告已写入：%s" % OUT_TXT)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
