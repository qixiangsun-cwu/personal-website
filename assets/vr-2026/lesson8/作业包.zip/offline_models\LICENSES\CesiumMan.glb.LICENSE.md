# CesiumMan.glb — 许可与署名

| 项 | 值 |
|---|---|
| 文件 | `demos/assets/models/CesiumMan.glb`（490,956 B） |
| SHA-256 | `659349b0a374b73d5362a61070039bc8601401bbdeacbece4f3680fb4bfd41b0` |
| 几何 | 4,672 三角面 / 3,273 顶点 / 1 网格 / 1 材质 / 1 纹理(JPEG) / 1 动画(2.0 s，57 通道) / 1 蒙皮 / 22 节点 |
| 来源仓库 | KhronosGroup/glTF-Sample-Models（旧仓库）`2.0/CesiumMan` |
| 下载直链 | https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/CesiumMan/glTF-Binary/CesiumMan.glb |
| 模型页 | https://github.com/KhronosGroup/glTF-Sample-Models/tree/master/2.0/CesiumMan |
| README（本结论出处） | https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/CesiumMan/README.md |
| 新仓库 README | https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Assets/main/Models/CesiumMan/README.md |

## ⚠️ 先看这条：新旧仓库的 CesiumMan.glb 不是同一个文件

用 `Invoke-WebRequest -Method Head` 实测（2026-10-27）：

| 来源 | Content-Length |
|---|---|
| 旧仓库 `glTF-Sample-Models/master/2.0/...` | **490,956 B** ← **本课用的就是这个** |
| 新仓库 `glTF-Sample-Assets/main/Models/...` | 438,044 B（已重新导出） |

本课文件与旧仓库版本 **SHA-256 完全一致**（已下载到临时目录比对，比对后删除，未覆盖交付文件）。
所以：**教学文档里给下载链接时，必须用上面的旧仓库直链**；给新仓库链接会下到另一个文件、字节数对不上，学生会以为下载错了。

## 一、许可

| 层次 | 版权持有人 | 许可 | 可商用 | 需署名 |
|---|---|---|---|---|
| 模型整体（Everything） | Cesium | **CC-BY 4.0** | ✅ | ⚠️ **必须** |
| Cesium logo（商标，不是版权） | Cesium | **Cesium Trademark Terms and Conditions**（不是 CC 许可） | — | 不得暗示背书 |

**整体判定：可商用（CC-BY 4.0）；必须署名；不得暗示 Cesium 对本作品背书。**

## 二、源站原文片段

旧仓库 `2.0/CesiumMan/README.md` 的 `License Information` 段原文：

```
## License Information

Donated by Cesium for glTF testing.  Please follow the [Cesium Trademark Terms and Conditions](https://github.com/AnalyticalGraphicsInc/cesium/wiki/CesiumTrademark.pdf).

This model is licensed under a [Creative Commons Attribution 4.0 International License](http://creativecommons.org/licenses/by/4.0/).
```

新版仓库 `Models/CesiumMan/README.md` 的 `Legal` 段原文：

```
© 2017, Cesium. Creative Commons Attribution 4.0 International
 - Cesium for Everything

© 2015, Cesium. Cesium Trademark or Logo
 - Non-copyrightable logo for Cesium logo
```

## 三、为什么它不只讲版权，还要讲商标

模型胸前/腹部贴的是 **Cesium 的 logo**。logo 本身「不可版权」（non-copyrightable），但受**商标**保护。
CC-BY 只解决「版权」层面的使用许可，**不授权你用这个 logo 去暗示官方背书**。

课堂用法：这是讲「**版权 ≠ 商标**」的最好例子——
> 「你可以合法使用这个模型，但不能把带 Cesium logo 的渲染图当成『Cesium 官方认可我们的项目』的宣传材料。」

## 四、可直接粘贴的署名文本

**中文版**：

```
模型：CesiumMan（Cesium 蒙皮行走角色）
- 版权：Cesium，CC-BY 4.0 — https://creativecommons.org/licenses/by/4.0/
- 特别说明：模型含 Cesium logo，Cesium Trademark Terms and Conditions 适用；本作品与 Cesium 无隶属或背书关系
- 获取渠道：Khronos glTF-Sample-Models — https://github.com/KhronosGroup/glTF-Sample-Models/tree/master/2.0/CesiumMan
```

**英文版**：

```
CesiumMan by Cesium, licensed under CC BY 4.0. Contains the Cesium logo;
Cesium Trademark Terms apply. Not affiliated with or endorsed by Cesium.
Source: Khronos glTF-Sample-Models.
```

## 五、许可全文链接

- CC-BY 4.0：https://creativecommons.org/licenses/by/4.0/legalcode
- Cesium 商标条款：https://github.com/AnalyticalGraphicsInc/cesium/wiki/CesiumTrademark.pdf

## 六、课堂可用性

✅ **可用**。用途：`02_模型工作台_WebXR.html` 的内嵌动画模型（2.0 s 行走循环，适合演示「动画播放/暂停/切换」）。
义务：署名 + 不暗示背书。不需要付费、不需要单独申请。
