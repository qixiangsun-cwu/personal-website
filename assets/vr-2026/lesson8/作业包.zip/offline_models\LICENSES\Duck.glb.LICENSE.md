# Duck.glb — 许可与署名

| 项 | 值 |
|---|---|
| 文件 | `demos/assets/models/Duck.glb`（120,484 B） |
| SHA-256 | `65bf938f54d6073e619e76e007820bbf980cdc3dc0daec0d94830ffc4ae54ab5` |
| 几何 | 4,212 三角面 / 2,399 顶点 / 1 网格 / 1 材质 / 1 纹理(PNG) / **0 动画** / 3 节点 |
| 来源仓库 | KhronosGroup/glTF-Sample-Models（旧仓库）`2.0/Duck` |
| 下载直链 | https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/Duck/glTF-Binary/Duck.glb |
| 模型页 | https://github.com/KhronosGroup/glTF-Sample-Models/tree/master/2.0/Duck |
| README（本结论出处） | https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/Duck/README.md |
| 许可全文 | https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Assets/main/LICENSES/SCEA.txt |

## 一、许可：SCEA Shared Source License, Version 1.0

| 项 | 值 |
|---|---|
| 版权持有人 | **Sony Computer Entertainment Inc.**（Copyright 2006） |
| 许可名称 | **SCEA Shared Source License, Version 1.0** |
| 是不是 CC 许可 | **不是**（这是本课最重要的分辨练习） |
| 可商用 | ✅ 是 —— §2 授权**没有 NonCommercial 限制** |
| 需署名 | ❌ Object Form 再分发**免**署名义务（§6）；Source Form 需要（§5） |

## 二、源站原文片段

旧仓库 `2.0/Duck/README.md` 的 `License Information` 段原文：

```
## License Information

Copyright 2006 Sony Computer Entertainment Inc.

Licensed under the SCEA Shared Source License, Version 1.0 (the "License"); you may not use this file except in compliance with the License. You may obtain a copy of the License at:

https://web.archive.org/web/20160320123355/http://research.scea.com/scea_shared_source_license.html

Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
```

新版仓库 `Models/Duck/README.md` 的 `Legal` 段（指向仓库内的许可全文）：

```
© 2006, Sony. SCEA Shared Source License, Version 1.0
 - Sony for Everything
```

## 三、许可关键条款摘录（原文引自 LICENSES/SCEA.txt）

**§2 License Grant（授权内容）** —— 为什么说它「可商用」：

```
Licensor hereby grants to You, free of charge subject to the terms and conditions of this License,
an irrevocable, non-exclusive, worldwide, perpetual, and royalty-free license to use, modify,
reproduce, distribute, publicly perform or display the Software in Object or Source Form.
```

→ 授权是**免费、不可撤销、非排他、全球、永久、免版税**，且**没有 NonCommercial 限制**。所以商用是允许的。

**§3 No Right to File for Patent（限制一）** —— 和 CC 完全不同的额外义务：

```
In exchange for the rights that are granted to You free of charge under this License, You agree that
You will not file for any patent application, seek copyright protection or take any other action that
might otherwise impair the ownership rights in and to the Software that may belong to SCEA or any of
the other contributors/authors of the Software.
```

**§5 Redistribution in Source Form（限制二）**：

```
You may redistribute copies of the Software, modifications or derivatives thereof in Source Code Form, provided that You:
    a. Include a copy of this License and any copyright notices with source
    b. Identify modifications if any were made to the Software
    c. Include a copy of all documentation accompanying the Software and modifications made by You
```

**§6 Redistribution in Object Form（为什么嵌进网页不用署名）**：

```
If You redistribute copies of the Software, modifications or derivatives thereof in Object Form only
(as incorporated into finished goods, i.e. end user applications) then You will not have a duty to
include any copies of the code, this License, copyright notices, other attributions or documentation.
```

→ **`.glb` 是 Object Form**。把它嵌进网页/App 这类「最终产品」时，**没有署名义务**。
但如果你把 `.gltf + .bin` 源文件改完再当源码分发，就落到 §5，必须附许可和版权声明。

## 四、可直接粘贴的署名文本（可选，非义务）

**中文版**（建议保留，出于学术诚信而非许可要求）：

```
模型：Duck（COLLADA 小黄鸭）
- 版权：Sony Computer Entertainment Inc. (2006)
- 许可：SCEA Shared Source License 1.0（非 CC 许可；允许商用；含「不就本软件申请专利/寻求版权保护」条款）
- 获取渠道：Khronos glTF-Sample-Models — https://github.com/KhronosGroup/glTF-Sample-Models/tree/master/2.0/Duck
```

**英文版**：

```
Duck — Copyright 2006 Sony Computer Entertainment Inc.
Licensed under the SCEA Shared Source License, Version 1.0.
Source: Khronos glTF-Sample-Models.
```

## 五、课堂可用性

✅ **可用**。用途：`02_模型工作台_WebXR.html` 的内嵌静态模型（演示「加载 / 归一化 / 换色 / 复制」）。
教学价值：它是**唯一一个「不是 CC 的免费许可」样本**——逼学生去读条款，而不是看到「免费」就当成 CC0。

**三条课堂提醒**：

1. 不要说它是「CC0 / 公共领域」——会同时错判许可名称和 §3 的义务。
2. 不要把 Duck 的 `.gltf` 源文件改完当源码分发——那会触发 §5 附许可义务。
3. 它没有动画（0 animation），别在工作台上指望它有行走循环。
